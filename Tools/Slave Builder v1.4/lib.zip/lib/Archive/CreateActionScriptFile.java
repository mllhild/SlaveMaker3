package girlBuilder.Export;

import girlBuilder.Assistant.AssistantInformation;
import girlBuilder.BasicInformation.BasicInformation;
import girlBuilder.BasicInformation.BasicInformation2;
import girlBuilder.BasicInformation.BasicInformation3;
import girlBuilder.DailyWalk.DailyWalk;
import girlBuilder.ItemPlacement.ItemPlacement;
import girlBuilder.NightAction.NightActions;
import girlBuilder.Tailor.Tailor;
import girlBuilder.Visit.DailyVisit;
import girlBuilder.Work.DailyWork;

import java.awt.Component;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JFrame;
import javax.swing.JProgressBar;

/**
 * This class is similar to Saving file, but it creates 1 ActionScript file
 * instead of a whole bunch of files and folders. The files created by this
 * class cannot be opened using Open command.
 */

public class CreateActionScriptFile {

	String fileName;
	final String ACTION_SCRIPT_OUTLINE = "lib" + File.separator + "Export"
										+ File.separator + "Slave-Girl.as";

	BasicInformation basicInfo;
	BasicInformation2 basicInfo2;
	BasicInformation3 basicInfo3;
	AssistantInformation assistInfo;
	Tailor tailorPanel;
	DailyWalk walkPanel;
	DailyVisit visitPanel;
	DailyWork workPanel;
	NightActions nightAction;
	ItemPlacement itemPlace;

	// Variable List
	String slaveName,longDescription,slaveMarketImage,difficulty,renoun ;
	
	//flags
	String dickGirl, tentacles, furries;
	
// BasicInformation tab 2
	
	//basic information tab 3
	String sexStatLevel[], dancingLevel, singingLevel, swimmingLevel;
	//assistant information
	String assistantPrice, shortAssistantDescript, longAssitantDescript, assistRape,
			assistTentacleRape, slaveLikeServent, assistStats[], assistExpression[];
	// Tailor tab
	String nakedDressFileList[], // list of files that refer to naked images of
			// the slave
			// sets up location of default dress name, and its image location
			defaultDressName, defaultDressImageAddress,

			dressName[], prices[], dressImgAddress[],
			dressDiscription[],
			dressStats[][], dressSpecialStats[][], soldAtTailor[];
	// daily walk tab
	// daily visit tab
	// Night actions Tab
	String actionsList[], instructionList[];
	// item placement tab
	int nakedHaloPos[][], nakedGagPos[][], nakedTailPos[][], nakedTiaraPos[][],
			nakedLeashPos[][],

			nakedSelectedGag[], nakedSelectedLeash[],

			nakedHaloScale[][], nakedTiaraScale[][], nakedGagScale[][],
			nakedTailScale[][], nakedLeashScale[][],

			nakedHaloRotate[], nakedGagRotate[], nakedTailRotate[],
			nakedTiaraRotate[], nakedLeashRotate[],

			defaultDressHaloPos[], defaultDressGagPos[], defaultDressTailPos[],
			defaultDressTiaraPos[], defaultDressLeashPos[],

			defaultDressHaloScale[], defaultDressGagScale[],
			defaultDressTailScale[], defaultDressTiaraScale[],
			defaultDressLeashScale[],

			defaultDressHaloRotate, defaultDressGagRotate,
			defaultDressTailRotate, defaultDressTiaraRotate,
			defaultDressLeashRotate,

			defaultDressSelectedLeash, defaultDressSelectedGag,

			haloPos[][], gagPos[][], tailPos[][], tiaraPos[][], leashPos[][],

			haloScale[][], gagScale[][], tailScale[][], tiaraScale[][],
			leashScale[][],

			haloRotate[], gagRotate[], tailRotate[], tiaraRotate[],
			leashRotate[],

			selectedLeash[], selectedGag[];

	String actionScriptFileStored;

	// reading and storing all the information into local variables

	// Basic information tab
	public void getBasicInformation(){
		slaveName = basicInfo.getSlaveName();
		
		longDescription = basicInfo.getDiscription();
		slaveMarketImage = basicInfo.getSlaveMarketImage();
		difficulty = basicInfo.getDifficulty();
		
		renoun = basicInfo2.getRenoun();
	}

	public void getFlags(){
		dickGirl = basicInfo2.getDickGirl();
		tentacles = basicInfo2.getTentacles();
		furries = basicInfo2.getFurries();
	}
	
	
	

	public void getBasicInfo3(){
		
		sexStatLevel = basicInfo3.getSexLevel();
		dancingLevel = basicInfo3.getDancingLevel ();
		singingLevel = basicInfo3.getSingingLevel();
		swimmingLevel = basicInfo3.getSwimmingLevel();
	}
	
	public void getAssistantInfo(){		
		assistantPrice = assistInfo.getAssistantPrice();
		shortAssistantDescript = assistInfo.getShortAssistantDescription();
		longAssitantDescript = assistInfo.getLongAssistantDescription();
		
		assistRape = assistInfo.getAssistantRape();
		assistTentacleRape = assistInfo.getAssistantTentaclesRape();
		slaveLikeServent = assistInfo.getSlaveLikeAssistant();
		
		assistStats = assistInfo.getAssistantStats();
		assistExpression = assistInfo.getAssistantDifficultyFactorExpressions();
	}
	
	// Tailor tab
	public void getTailor() {
		// Tailor tailorPanel;

		defaultDressName = tailorPanel.getDefaultDressName();

		dressName = tailorPanel.getDressNames();
		prices = tailorPanel.getPrices();

		dressSpecialStats = tailorPanel.getDressSpecialStats();

		dressImgAddress = tailorPanel.getDressImageAddress();
		dressDiscription = tailorPanel.getDressDiscriptions();
		
		soldAtTailor = tailorPanel.getDressSoldAtTailor();
		dressStats = tailorPanel.getDressStats();
	}

	// daily walk tab
	public void getDailyWalk() {
		// DailyWalk walkPanel;
	}

	// daily visit tab
	public void getDailyVisit() {
		// DailyVisit visitPanel;
	}

	// daily visit tab
	public void getDailyWork() {
		// DailyWork workPanel;
	}

	// Night actions Tab
	public void getNightActions() {
		// NightActions nightAction;
		actionsList = nightAction.getActionsList();
		instructionList = nightAction.getInstructions();
	}

	// Item placement tab
	public void getItemPlacement() {
		// ItemPlacement itemPlace;
		
		nakedHaloPos = itemPlace.getNakedHaloPos();
		nakedGagPos = itemPlace.getNakedGagPos();
		nakedTailPos = itemPlace.getNakedTailPos();
		nakedTiaraPos = itemPlace.getNakedTiaraPos();
		nakedLeashPos = itemPlace.getNakedLeashPos();

		nakedSelectedGag = itemPlace.getNakedSelectedGag();
		nakedSelectedLeash = itemPlace.getNakedSelectedLeash();

		nakedHaloScale = itemPlace.getNakedHaloScale();
		nakedTiaraScale = itemPlace.getNakedTiaraScale();
		nakedGagScale = itemPlace.getNakedGagScale();
		nakedTailScale = itemPlace.getNakedTailScale();
		nakedLeashScale = itemPlace.getNakedLeashScale();

		nakedHaloRotate = itemPlace.getNakedHaloRotate();
		nakedGagRotate = itemPlace.getNakedGagRotate();
		nakedTailRotate = itemPlace.getNakedTailRotate();
		nakedTiaraRotate = itemPlace.getNakedTiaraRotate();
		nakedLeashRotate = itemPlace.getNakedLeashRotate();

		
		// read default dress information
		defaultDressHaloPos = itemPlace.getDefaultDressHaloPos();
		defaultDressGagPos = itemPlace.getDefaultDressGagPos();
		defaultDressTailPos = itemPlace.getDefaultDressTiaraPos();
		defaultDressTiaraPos = itemPlace.getDefaultDressTiaraPos();
		defaultDressLeashPos = itemPlace.getDefaultDressLeashPos();

		defaultDressHaloScale = itemPlace.getDefaultDressHaloScale();
		defaultDressGagScale = itemPlace.getDefaultDressGagScale();
		defaultDressTailScale = itemPlace.getDefaultDressTailScale();
		defaultDressTiaraScale = itemPlace.getDefaultDressTiaraScale();
		defaultDressLeashScale = itemPlace.getDefaultDressLeashScale();

		defaultDressHaloRotate = itemPlace.getDefaultDressHaloRotate();
		defaultDressGagRotate = itemPlace.getDefaultDressGagRotate();
		defaultDressTailRotate = itemPlace.getDefaultDressTailRotate();
		defaultDressTiaraRotate = itemPlace.getDefaultDressTiaraRotate();
		defaultDressLeashRotate = itemPlace.getDefaultDressLeashRotate();

		defaultDressSelectedLeash = itemPlace.getDefaultDressSelectedLeash();
		defaultDressSelectedGag = itemPlace.getDefaultDressSelectedGag();

		
		// read all the other dress information
		haloPos = itemPlace.getDressHaloPos();
		gagPos = itemPlace.getDressGagPos();
		tiaraPos = itemPlace.getDressTiaraPos();
		tailPos = itemPlace.getDressTailPos();
		leashPos = itemPlace.getDressLeashPos();

		haloScale = itemPlace.getDressHaloScale();
		gagScale = itemPlace.getDressGagPos();
		tiaraScale = itemPlace.getDressTiaraScale();
		tailScale = itemPlace.getDressTailScale();
		leashScale = itemPlace.getDressLeashScale();

		haloRotate = itemPlace.getDressHaloRotate();
		gagRotate = itemPlace.getDressGagRotate();
		tiaraRotate = itemPlace.getDressTiaraRotate();
		tailRotate = itemPlace.getDressTailRotate();
		leashRotate = itemPlace.getDressLeashRotate();

		selectedLeash = itemPlace.getDressSelectedLeash();
		selectedGag = itemPlace.getDressSelectedGag();
	}

	// read the basic Action script file outline
	private void readASFileOutline() {
		// Initialise String buffer
		actionScriptFileStored = "";
		try {
			File file = new File(ACTION_SCRIPT_OUTLINE);

			BufferedInputStream bis = new BufferedInputStream(
					new FileInputStream(file));
			byte[] bytes = new byte[Integer.parseInt(file.length() + "") - 3];

			bis.read(new byte[3]);// skip the first 3 bytes (some weird
			// characters)
			bis.read(bytes);// read and store the whole file into the byte array

			bis.close();// close the file

			// store the file into the StringBuffer array
			actionScriptFileStored = new String(bytes);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// this method writes the text file of the slave
	private void writeTextFile() {
		String fileName2 = new File(fileName).getParent() + File.separator
				+ "SlaveGirl";
		String nameStore = slaveName, discriptionStore = longDescription, 
				imgAddress = slaveMarketImage, slaveSWF = fileName, 
				difficultyGirl = difficulty, renounReq = renoun, mode = difficulty ;
		int counter = 0;

		// checking if there are any previous slave files. Don't want to replace
		// them
		while (new File(fileName2 + counter + ".txt").exists())
			counter++;
		fileName2 = fileName2 + counter + ".txt";

		// prepare information for writing
		nameStore = nameStore.trim();
		discriptionStore = discriptionStore.replace('\n', ' ');
		discriptionStore = discriptionStore.trim();
		imgAddress = new File(imgAddress).getName();
		slaveSWF = new File(slaveSWF).getName();
		slaveSWF = slaveSWF.replaceAll(".as", ".swf");
		difficultyGirl = difficultyGirl.toUpperCase() + " MODE : " + nameStore
				+ " : ";

		try {
			FileWriter outFile = new FileWriter(fileName2);
			PrintWriter file = new PrintWriter(outFile);

			file.print("girlname=" + nameStore); // write name
			file.print("&girldesc=" + difficultyGirl + " : "
							+ discriptionStore); // write description
			file.print("&image=" + imgAddress); // write the location of the
			// slave market image
			file.print("&gamefile=" + slaveSWF); // write the name of the slave
			// swf file (predicted name)
			file.print("&renown=" + renounReq.trim().toLowerCase()); // the
			// minimum
			// required
			// renoum
			file.print("&mode=" + mode.toLowerCase()); // the difficulty
			file.print("&Dickgirls=" + dickGirl.trim().toLowerCase());
			file.print("&Tentacles=" + tentacles.trim().toLowerCase());
			file.print("&Furries=" + furries.trim().toLowerCase());

			// close the file
			file.close();
			outFile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	
	
	/*------------------------------------------Basic information tab 1----------------------*/
	
	
	
	
	
	
	
	

	
	//----------------------------------Basic Information Tab 2--------------

	private void prepareSpecialStat() {
		String store = "";

		if (Boolean.parseBoolean(activateSpecial)) {
			store = '\t' + "_root.ShowSpecialStat (\"" + specialStatName+ "\");" + '\n';
			store = store+ '\t';
			store = store + "_root.Var";
			store = store + basicInfo.getStatsList()[basicInfo.getStatsList().length - 1];
			store = store + " = " + stats[stats.length - 1] + ";" + '\n';
			
			store = store + '\t' + "_root.Max";
			store = store + basicInfo2.getLimitStatsList()[basicInfo2.getLimitStatsList().length - 1];
			store = store + " = " + limitValue[limitValue.length - 1] + ";" + '\n';

		}
		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬SpecialStatSetup¬", store);
	}

	private void prepareSlaveInitialStats() {
		String store = "", store2[], store3[] = basicInfo.getStatsList(), store4[] = stats, statsNames[];
		int counter = 0;

		while (!(store3[counter].equalsIgnoreCase("Charisma")))
			counter++;

		statsNames = new String[store3.length - counter];
		store2 = new String[store3.length - counter];

		// prepare the variable names
		for (int x = 0, y = counter; x < statsNames.length; x++, y++) {
			statsNames[x] = store3[y];
			store2[x] = store4[y];

			statsNames[x] = statsNames[x].replaceAll(" ", "");
			statsNames[x] = statsNames[x].replaceAll("-", "");
		}

		for (int x = 0; x < statsNames.length; x++)
			if (statsNames[x].equalsIgnoreCase("Libido/Lust"))
				statsNames[x] = statsNames[x].replace("Libido/Lust", "Libido");

		for (int x = 0; x < statsNames.length - 1; x++)
			store = store + '\t' + "_root.Var" + statsNames[x] + " = "
					+ store2[x] + ";" + '\n';

		// prepare sexuality
		store = store + '\t' + "_root.VarSexuality = " + sexuality + ";";

		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬TrainingTime¬", store4[0]);
		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬InitializeVariables¬", store);
	}

	private void prepareSlaveDifficultyStats() {
		String store = "", store2[] = difficultyValue, store3[] = basicInfo2
				.getDifficultyStatsList();

		for (int x = 0; x < store3.length; x++) {
			if (store3[x].contains("Exhibition"))
				store3[x] = store3[x].replace("Exhibition", "Exhib");
		}

		// remove - and spaces in store3 values
		for (int x = 0; x < store3.length; x++) {
			store3[x] = store3[x].replaceAll(" ", "");
			store3[x] = store3[x].replaceAll("-", "");
		}

		//
		for (int x = 0; x < store3.length; x++) {
			store = store + '\t' + "_root." + store3[x] + " = " + store2[x]
					+ ";" + '\n';
		}

		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬DifficultySexActs¬", store);

	}

	private void prepareSlaveStatLimit() {
		String store = "", store2[] = limitValue, store3[] = basicInfo2
				.getLimitStatsList();

		for (int x = 0; x < store3.length; x++) {
			store3[x] = store3[x].replaceAll(" ", "");
			store3[x] = store3[x].replaceAll("-", "");
		}

		for (int x = 0; x < store3.length - 1; x++)
			store = store + '\t' + "_root.Max" + store3[x] + " ( " + store2[x]
					+ " );" + '\n';

		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬MaxVariableValues¬", store);
	}
	
	private void prepareSlaveMilkable() {
		actionScriptFileStored = actionScriptFileStored.replaceAll("¬IsMilkable¬", milkable);
	}
	
	
	//---------------------------------Basic Information Tab 3----------------
	
	//---------------------------------Assistant Information Tab------------------
	
	
	
	//------------------------------Tailor Tab-------------------------------
	
	
	// prepare Information relating to dresses
	/**
	 * This method sets up : - spot where it is to be sold - Name of the dress -
	 * description about this dress. It it displayed when the dress is
	 * highlighted - the price of the dress it is sold for in the tailor shop
	 * */
	private void prepareDressBasicDetails() {
		String store = "", store2[] = dressDiscription, store3[] = dressName, store4[] = prices;

		// write basic details
		store = '\t' + "_root.setDressDetails (0, " + defaultDressName + ");"
				+ '\n';

		/*
		 * this replaces all the '\n' (new line characters) with '\r' (return
		 * character) so that when it is written in the as file, it writes '\r'
		 * instead of creating a new line
		 */
		for (int x = 0; x < store2.length; x++)
			store2[x] = store2[x].replace('\n', '\r');

		// store all the dress details description with proper command into a
		// variable
		for (int x = 0, y = 1; x < store2.length; x++, y++) {
			// dress command to set up dress details
			store = store + '\t' + "_root.SetDressDetails(";
			// which dress details need to be setup
			store = store + y + ", ";
			// setup the name of the dress
			store = store + "\"" + store3[x] + "\"" + ", ";
			// setup the long description of the dress
			store = store + " \"" + store2[x] + "\"" + ",";
			// setup if the dress is to be sold at the tailor shop
			store = store + soldAtTailor[x] + ", ";
			// setup the price of the dress
			store = store + store4[x] + ");" + '\n';
		}

		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬DressDiscription¬", store);
	}

	/** Sets up all the special stats of all the other dresses */
	private void prepareDressSpecialStats() {
		String store = "", store2[][] = dressSpecialStats, store3[] = tailorPanel
				.getSpecialDressStatsList(), commands[];

		// format the names properly so that they can used as commands
		commands = new String[store3.length - 1];

		for (int x = 0; x < commands.length; x++) {
			commands[x] = "SetDress"
					+ store3[x].substring(0, store3[x].indexOf(' '));

			if (commands[x].indexOf('-') != -1)
				commands[x] = commands[x].replace("-", "");

		}

		for (int x = 0; x < store2.length; x++)
			for (int y = 0; y < store2[x].length; y++)
				if (Boolean.parseBoolean(store2[x][y])) {
					store = store + '\t' + commands[y] + " (" + x + ");" + '\n';
				}

		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬DressSpecialStats¬", store);
	}

	/**
	 * This method sets up the point modification of each dress when the user
	 * makes the slave put on/remove any of the 6 dresses
	 */
	private void prepareWearOrRemoveDresses() {
		String store = "", dressList[] = tailorPanel.getDressCategories();

		// prepare wear dress stuff
		for (int x = 0; x < dressList.length; x++) {
			// prepare wear things format
			store = store + '\t';
			if (x != 0)
				store = store + "else ";
			store = store + "if (_root.DressWorn == " + (x + 1) + ")" + '\n';

			store = store + '\t' + '\t' + "_root.PointsMod (";

			for (int y = 0; y < (dressStats[x].length); y++) {
				store = store + dressStats[x][y];

				if (y != dressStats[x].length - 1)
					store = store + ", ";
			}

			store = store + ");" + '\n' + '\n';
		}

		// replace information
		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬WearDress¬", store);

		// clear all the information stored in this variable
		store = "";

		// prepare remove dress stuff
		for (int x = 0; x < dressList.length; x++) {
			// prepare wear things format
			store = store + '\t' + "if (_root.DressWorn == " + (x + 1) + ")"
					+ '\n';

			store = store + '\t' + '\t' + "_root.PointsMod (";

			for (int y = 0; y < (dressStats[x].length); y++) {
				if (!(dressStats[x][y].equalsIgnoreCase("0")))
					store = store + "-";
				store = store + dressStats[x][y];
				if (y != dressStats[x].length - 1)
					store = store + ", ";
			}

			store = store + ");" + '\n' + '\n';
		}

		//System.out.println("Remove Dress " + '\n' + store);
		// replace information
		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬RemoveDress¬", store);

	}

	/**
	 * All the night actions that need to be done would be replaced here NOTE:
	 * currently this method does nothing. This tab is also currently disabled
	 */
	private void replaceInfoFromNightAction() {

	}

	/** This method setups all the location of all the items on the dresses. */
	private void prepareItemPlacementInformation() {
		String store = "", dressList[] = tailorPanel.getDressCategories();

		// prepare showNaked () function
		if (nakedDressFileList.length < 2) {
			store = '\t' + "NakedClip.gotoAndStop (1);" + '\n';
		} else {
			store = '\t' + "NakedClip.gotoAndStop (__root.ChoiceNaked(1, "
					+ nakedDressFileList.length + ");";
			store = store + '\n' + "" + '\n';

			store = store + '\t' + "switch (NakedChoice){" + '\n';
		}

		if (nakedDressFileList == null) {
			store = "";
		} else {
			for (int x = 0; x < nakedDressFileList.length; x++) {

				store = store + '\t' + "" + '\t' + "case " + (x + 1) + ":"
						+ '\n';

				// write halo position of each image
				store = store + '\t' + "" + '\t' + "PositionHalo (";
				// write halo position
				store = store + nakedHaloPos[x][0] + ", " + nakedHaloPos[x][1]
						+ ", ";
				// write halo rotate
				store = store + nakedHaloRotate[x] + ", ";
				// write halo scale
				store = store + nakedHaloScale[x][0] + ", "
						+ nakedHaloScale[x][1] + ");" + '\n';

				// write gag position for each image
				store = store + '\t' + "" + '\t';
				store = store + "PositionGag (";
				store = store + nakedSelectedGag [x] + ", ";
				store = store + nakedGagPos[x][0] + ", " + nakedGagPos[x][1]
						+ ", ";
				store = store + nakedGagRotate[x] + ", ";
				store = store + nakedGagScale[x][0] + ", "
						+ nakedGagScale[x][1] + ");" + '\n';

				// write pony tail information for each image
				store = store + '\t' + "" + '\t';
				store = store + "PositionTail (";
				store = store + nakedTailPos[x][0] + ", " + nakedTailPos[x][1]
						+ ", ";
				store = store + nakedTailRotate[x] + ", ";
				store = store + nakedTailScale[x][0] + ", "
						+ nakedTailScale[x][1] + ");" + '\n';

				// write tiara information for each image
				store = store + '\t' + "" + '\t';
				store = store + "PositionNymphsTiara (";
				store = store + nakedTiaraPos[x][0] + ", "
						+ nakedTiaraPos[x][1] + ", ";
				store = store + nakedTiaraRotate[x] + ", ";
				store = store + nakedTiaraScale[x][0] + ", "
						+ nakedTiaraScale[x][1] + ");" + '\n';

				// write leash information
				store = store + '\t' + "" + '\t';
				store = store + "PositionLeash (";
				store = store + nakedSelectedLeash[x] + ", ";
				store = store + nakedLeashPos[x][0] + ", "
						+ nakedLeashPos[x][1] + ", ";
				store = store + nakedLeashRotate[x] + ", ";
				store = store + nakedLeashScale[x][0] + ", "
						+ nakedLeashScale[x][1] + ");" + '\n';

			}
		}

		actionScriptFileStored = actionScriptFileStored.replaceAll("¬Naked¬",
				store);

		store = ""; // reset store variable

		// prepare default dress information
		store = '\t' + "if (_root.DressWorn == 0){" + '\n';

		store = store + '\t' + "" + '\t';
		store = store + "PositionHalo (";
		store = store + defaultDressHaloPos[0] + ", " + defaultDressHaloPos[1]
				+ ", ";
		store = store + defaultDressHaloRotate + ", ";
		store = store + defaultDressHaloScale[0] + ", "
				+ defaultDressHaloScale[1] + ", ";
		store = store + ");" + '\n';

		// position gag on default dress
		store = store + '\t' + "" + '\t';
		store = store + "PositionGag (";
		store = store + defaultDressSelectedGag + ", ";		
		store = store + defaultDressGagPos[0] + ", " + defaultDressGagPos[1] + ", ";
		store = store + defaultDressGagRotate + ", ";
		store = store + defaultDressGagScale[0] + ", "
				+ defaultDressGagScale[1] + ", ";
		store = store + ");" + '\n';

		// position pony tail on default dress
		store = store + '\t' + "" + '\t';
		store = store + "PositionTail (";
		store = store + defaultDressTailPos[0] + ", " + defaultDressTailPos[1]
				+ ", ";
		store = store + defaultDressTailRotate + ", ";
		store = store + defaultDressTailScale[0] + ", "
				+ defaultDressTailScale[1] + ", ";
		store = store + ");" + '\n';

		// position nymph tiara on default dress
		store = store + '\t' + "" + '\t';
		store = store + "PositionNymphsTiara (";
		store = store + defaultDressTiaraPos[0] + ", "
				+ defaultDressTiaraPos[1] + ", ";
		store = store + defaultDressTiaraRotate + ", ";
		store = store + defaultDressTiaraScale[0] + ", "
				+ defaultDressTiaraScale[1] + ", ";
		store = store + ");" + '\n';

		// position
		store = store + '\t' + "" + '\t';
		store = store + "PositionLeash (";
		store = store + defaultDressSelectedLeash + ", ";
		store = store + defaultDressLeashPos[0] + ", "
				+ defaultDressLeashPos[1] + ", ";
		store = store + defaultDressLeashRotate + ", ";
		store = store + defaultDressLeashScale[0] + ", "
				+ defaultDressLeashScale[1] + ", ";
		store = store + ");" + '\n';

		// end if for the default dress
		store = store + '\t' + "}";

		for (int x = 0; x < dressList.length; x++) {
			store = store + '\t';
			store = store + "else if (_root.DressWorn == ";
			store = store + (x + 1) + "){" + '\n';

			store = store + '\t' + "" + '\t';
			store = store + "PositionHalo ( ";
			store = store + haloPos[x][0] + ", " + haloPos[x][1] + ", ";
			store = store + haloRotate[x] + ", ";
			store = store + haloScale[x][0] + ", " + haloScale[x][1];
			store = store + ");" + '\n';

			store = store + '\t' + "" + '\t';
			store = store + "PositionGag (1";
			store = store + selectedGag [x] + ", ";
			store = store + gagPos[x][0] + ", " + gagPos[x][1];
			store = store + gagRotate[x] + ", ";
			store = store + gagScale[x][0] + ", " + gagScale[x][1];
			store = store + ");" + '\n';

			store = store + '\t' + "" + '\t';
			store = store + "PositionLeash (";
			store = store + selectedLeash[x] + ", ";
			store = store + leashPos[x][0] + ", " + leashPos[x][1] + ", ";
			store = store + leashRotate[x] + ", ";
			store = store + leashScale[x][0] + ", " + leashScale[x][1];
			store = store + ");" + '\n';

			store = store + '\t' + '\t';
			store = store + "PositionNymphsTiara (";
			store = store + tiaraPos[x][0] + ", " + tiaraPos[x][1] + ", ";
			store = store + tiaraRotate[x] + ", ";
			store = store + tiaraScale[x][0] + ", " + tiaraScale[x][1];
			store = store + ");" + '\n';

			store = store + '\t' + '\t';
			store = store + "PositionTail (";
			store = store + tailPos[x][0] + ", " + tailPos[x][1] + ", ";
			store = store + tailRotate[x] + ", ";
			store = store + tailScale[x][0] + ", " + tailScale[x][1];
			store = store + ");" + '\n';

			// close if structure brackers
			store = store + '\t' + "}" + '\n';

			// leave a blank line
			store = store + '\n';
		}

		//System.out.println(store);

		actionScriptFileStored = actionScriptFileStored.replaceAll(
				"¬ShowDressIfStructure¬", store);
	}

	/** This part of the program creates/writes the actionscript file. */
	private void writeActionScriptFile() {
		try {
			FileWriter outFile = new FileWriter(fileName);
			PrintWriter file = new PrintWriter(outFile);

			file.print(actionScriptFileStored);

			file.close();
			outFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void saveFile(String name, Component c) {
		JFrame f = new JFrame();
		JProgressBar bar = new JProgressBar(0, 26);

		bar.setStringPainted(true);
		f.getContentPane().add(bar);
		f.setLocationRelativeTo(c);
		f.pack();
		f.setVisible(true);
		bar.setValue(0);

		fileName = name;
		bar.setValue(bar.getValue() + 1);

		// read the information entered by the user
		getBasicStats();
		bar.setValue(bar.getValue() + 1);
		getBasicInfo2();
		bar.setValue(bar.getValue() + 1);
		getBasicInfo3();
		
		getAssistantInfo();
		
		getTailor();
		bar.setValue(bar.getValue() + 1);
		getDailyWalk();
		bar.setValue(bar.getValue() + 1);
		getDailyVisit();
		bar.setValue(bar.getValue() + 1);
		getDailyWork();
		bar.setValue(bar.getValue() + 1);
		getNightActions();
		bar.setValue(bar.getValue() + 1);
		getItemPlacement();
		bar.setValue(bar.getValue() + 1);

		// write the initial text file
		writeTextFile();
		bar.setValue(bar.getValue() + 1);

		readASFileOutline();
		bar.setValue(bar.getValue() + 1);

		// prepare slave's basic information for writing
		prepareSlaveNameForAS();
		bar.setValue(bar.getValue() + 1);
		prepareGenderSlave();
		bar.setValue(bar.getValue() + 1);
		prepareSlaveInitialStats();
		bar.setValue(bar.getValue() + 1);
		prepareSlaveDifficultyStats();
		bar.setValue(bar.getValue() + 1);
		prepareSlaveStatLimit();
		bar.setValue(bar.getValue() + 1);
		prepareSpecialStat();
		bar.setValue(bar.getValue() + 1);
		prepareSlaveMilkable();
		bar.setValue(bar.getValue() + 1);

		// prepare the description that is displayed when the slave is used as
		// an assistant
		//prepareAssistantDescriptionForAS();
		bar.setValue(bar.getValue() + 1);

		prepareSlaveVitals(); // write the slave vitals
		bar.setValue(bar.getValue() + 1);

		// prepare tailor information
		prepareDressBasicDetails();
		bar.setValue(bar.getValue() + 1);
		prepareDressSpecialStats();
		bar.setValue(bar.getValue() + 1);

		prepareWearOrRemoveDresses();
		bar.setValue(bar.getValue() + 1);

		// prepare the night actions
		replaceInfoFromNightAction();
		bar.setValue(bar.getValue() + 1);

		// prepare locations of the items
		prepareItemPlacementInformation();
		bar.setValue(bar.getValue() + 1);

		// create the action script file
		writeActionScriptFile();
		bar.setValue(bar.getValue() + 1);

		f.dispose();
	}

	public void saveFile(Component c) {
		String store = name;
		int spaceIndex = store.indexOf(' ');

		if (spaceIndex != -1)
			store = store.substring(0, spaceIndex);

		store = "Slave-" + store + ".as";

		saveFile(store, c);
	}

	public CreateActionScriptFile(BasicInformation basic, BasicInformation2 basic2,
			BasicInformation3 basic3, AssistantInformation assist,
			Tailor tailor, DailyWalk walk,
			DailyVisit visit, DailyWork work, NightActions night,
			ItemPlacement item) {

		basicInfo = basic;
		basicInfo2 = basic2;
		basicInfo3 = basic3;
		assistInfo = assist;
		
		tailorPanel = tailor;
		walkPanel = walk;
		visitPanel = visit;
		workPanel = work;
		nightAction = night;
		itemPlace = item;
	}

}

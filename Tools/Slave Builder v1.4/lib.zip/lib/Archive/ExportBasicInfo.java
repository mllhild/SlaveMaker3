/**
 * 
 */
package girlBuilder.Export;

import girlBuilder.BasicInformation.BasicInformation3;

/**
 * @author Moose
 *
 *This class modifies the variable that contains the actionscript file
 *and returns modified variable that contains all the information about
 *the slave that was read in all the three basic information tabs
 */
public class ExportBasicInfo {
	
	
	
	BasicInformation3 basicInfo3;
	
	
	//basic info tab 1
	
	
	
	
	
	
	
	String asFile;
	
	
	public String getBasicInformation (String file){
		asFile = file;
		
		return asFile;
	}
}

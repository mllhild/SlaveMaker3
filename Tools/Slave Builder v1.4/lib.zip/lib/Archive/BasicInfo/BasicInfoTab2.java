/**
 * 
 */
package girlBuilder.Export.BasicInfo;

import girlBuilder.BasicInformation.BasicInformation2;

/**
 * @author Devdoot Laptop
 *
 */
public class BasicInfoTab2 {

	
	BasicInformation2 basic;
	
	//basic info tab 2
	String difficultyValue[], limitValue[], sexuality;
	
	public void getInformation() {
		difficultyValue = basic.getDifficulty();
		limitValue = basic.getStatLimit();

		sexuality = basic.getSexuality();

	}
	
	public BasicInfoTab2 (BasicInformation2 basic){
		this.basic = basic;
	}
	
}

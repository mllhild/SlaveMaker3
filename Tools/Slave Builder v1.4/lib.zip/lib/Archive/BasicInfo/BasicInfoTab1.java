/**
 * 
 */
package girlBuilder.Export.BasicInfo;

import girlBuilder.BasicInformation.BasicInformation;

/**
 * @author Moose
 *
 */
public class BasicInfoTab1 {
	
	BasicInformation basicInfo;
	
	String name, gender, stats[], slaveMarketImage, difficulty,
					discription, shortSlaveDiscription,
					activateSpecial, specialStatName;
	String age, bust, waist, height, bloodType, hips, weight;
	
	boolean isSpecialActive;
	
	
	String asFile;
	
	public void getBasicStats() {
		// BasicInformation basicInfo;

		name = basicInfo.getName();
		gender = basicInfo.getGender();

		stats = basicInfo.getStats();

		difficulty = basicInfo.getDifficulty();



		shortSlaveDiscription = basicInfo.getShortSlaveDiscription();

		isSpecialActive = basicInfo.isSpecialActive();
		
		specialStatName = basicInfo.getSpecialStatName();
		
		
		age = basicInfo.getAge();
		bust = basicInfo.getBust();
		waist = basicInfo.getWaist();
		height = basicInfo.getSlaveHeight();
		bloodType = basicInfo.getBloodType();
		hips = basicInfo.getHips();
		weight = basicInfo.getWeight();
	}
	
	
	// prepare basic information about the slave
	private void addSlaveNameToAS() {
		asFile = asFile.replace("¬Name¬", "\"" + name + "\"");
	}

	private void setupSlaveGender() {
		int genderStore;
		if (gender.equalsIgnoreCase("Male"))
			genderStore = 1;
		else if (gender.equalsIgnoreCase("Dick Girl"))
			genderStore = 3;
		else if (gender.equalsIgnoreCase("Male Twins"))
			genderStore = 4;
		else if (gender.equalsIgnoreCase("Female Twins"))
			genderStore = 5;
		else if (gender.equalsIgnoreCase("Dick Girl Twins"))
			genderStore = 6;
		else
			genderStore = 2;

		asFile = asFile.replace("¬SlaveGender¬", genderStore + "");
	}
	
	
	private void setupSlaveVitals() {
		String temp = "\"" + shortSlaveDiscription + "\"";
		asFile = asFile.replace("¬SlaveDiscription¬", temp);
		
		asFile = asFile.replace("¬Age¬", 		age);
		asFile = asFile.replace("¬BustSize¬", bust);
		asFile = asFile.replace("¬Waist¬",	waist);
		asFile = asFile.replace("¬Hips¬",		hips);
		asFile = asFile.replace("¬Height¬", 	height);
		asFile = asFile.replace("¬Weight¬", 	weight);
		asFile = asFile.replace("¬BloodType¬",bloodType);
	}

	
	
	public String addBasicInfoTab1ToAS(String file){
		asFile = file;
		
		
		addSlaveNameToAS();
		setupSlaveGender();
		setupSlaveVitals();
		
		return asFile;
	}
	
	public BasicInfoTab1(BasicInformation basic){
		basicInfo = basic;
	}
}

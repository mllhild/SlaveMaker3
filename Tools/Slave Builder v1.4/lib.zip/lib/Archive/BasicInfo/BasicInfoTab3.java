/**
 * 
 */
package girlBuilder.Export.BasicInfo;

import girlBuilder.BasicInformation.BasicInformation3;

/**
 * @author Moose
 *
 */
public class BasicInfoTab3 {
	
	BasicInformation3 basic;
	
	
	
	
	
	public BasicInfoTab3 (BasicInformation3 basic){
		this.basic = basic;
	}
}
